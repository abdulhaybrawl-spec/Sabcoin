SabCoin Mini App — boshlang‘ich frontend prototipi

Fayllar:
- index.html: responsive Telegram Mini App interfeysi (dark + gold).
- Rasmlar: hozircha bo‘sh joylar; keyin o‘zingiz qo‘shasiz.

Muhim:
Bu paket interfeys prototipi. Balans, haqiqiy xaridlar, coin o‘tkazmalari, reyting va DICE mukofotlari hali backend/API ga ulanmagan. Hozirgi demo DICE Coin o‘zgartirmaydi.

Rasmlar:
1. Hosting loyihasida images/ papka yarating.
2. Masalan images/garama.png faylini joylang.
3. index.html ichidagi products ro‘yxatida mos mahsulotning image qiymatini "images/garama.png" qiling.

Telegram Mini App ulash:
1. index.html ni HTTPS qo‘llaydigan hostingga joylash kerak.
2. @BotFather orqali botning Menu Button/Web App URL sozlamasiga shu HTTPS URL qo‘yiladi.
3. Haqiqiy balans va o‘tkazmalar uchun server endpointlari kerak. Telegram initData serverda tekshirilishi lozim; foydalanuvchi ID ga faqat brauzerdan kelgan qiymatga ishonmang.
4. NxCreate botidagi scusers/scorders bazasiga to‘g‘ridan-to‘g‘ri brauzerdan ulanish mumkin emas; server tomondan xavfsiz ulash kerak.
